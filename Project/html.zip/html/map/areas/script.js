
  function heading(){
   var vis = document.getElementById("heading");
   vis.style.visibility="visible";
   var header = document.getElementById("head");
   header.style.height="300px";
  }